<!DOCTYPE html>

<html lang="en">
<head>
  <meta charset="utf-8">

  <title>The HTML5 Herald</title>
  <title>Documentry</title>

  <?php wp_head();?>

</head>
<body>

